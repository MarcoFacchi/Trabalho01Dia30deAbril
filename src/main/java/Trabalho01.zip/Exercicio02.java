
public class Exercicio02 {
    public static void main(String[] args) {
        int i = 2;
        int soma =0;
       do{
          i = i+2;
          soma = i+i;
       } while(i<=500);{
        System.out.println("multiplos de 2"+soma);}
    }
}

