
public class Exercicio01 {
    public static void main(String[] args) {
        int N = 1;
        while(N <= 100){
            System.out.println(N); 
            N++;
        }
        }
    }

