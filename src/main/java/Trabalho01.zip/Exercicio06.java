
public class Exercicio06 {
    public static void main(String[] args) {
        int celsius = 10;
        while (celsius <= 100){
            double fahrenheit = celsius * 18 +32;
            System.out.println(celsius+"graus celsius equivale a"+fahrenheit+"fahrenheit");
            celsius = celsius + 10;
        }
        }
    }
  

